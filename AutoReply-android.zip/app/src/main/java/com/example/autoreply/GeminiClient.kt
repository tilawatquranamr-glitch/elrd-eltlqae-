package com.example.autoreply

import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object GeminiClient {
    private const val TAG = "GeminiClient"

    /**
     * history: قائمة (role, text) حيث role = "user" أو "model".
     * بترجع null لو حصل خطأ، والسبب بيتخزن في Store.lastError.
     * لازم تتنادى من thread خلفي (مش الـ main thread).
     */
    fun reply(
        apiKey: String,
        model: String,
        system: String,
        history: List<Pair<String, String>>,
        userText: String,
    ): String? {
        if (apiKey.isBlank()) {
            Store.lastError = "مفتاح Gemini API فاضي. ضيفه من الإعدادات."
            return null
        }
        return try {
            val contents = JSONArray()
            history.forEach { (role, text) ->
                contents.put(
                    JSONObject()
                        .put("role", role)
                        .put("parts", JSONArray().put(JSONObject().put("text", text)))
                )
            }
            contents.put(
                JSONObject()
                    .put("role", "user")
                    .put("parts", JSONArray().put(JSONObject().put("text", userText)))
            )
            val body = JSONObject()
                .put(
                    "system_instruction",
                    JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system)))
                )
                .put("contents", contents)
                .put("generationConfig", JSONObject().put("temperature", 0.7))

            val conn = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
                .openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.connectTimeout = 15000
            conn.readTimeout = 45000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            conn.setRequestProperty("x-goog-api-key", apiKey)
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val response = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            conn.disconnect()

            if (code !in 200..299) {
                Log.e(TAG, "HTTP $code: $response")
                val msg = runCatching {
                    JSONObject(response).getJSONObject("error").getString("message")
                }.getOrDefault(response.take(150))
                Store.lastError = "Gemini رجّع خطأ $code: $msg"
                return null
            }

            val parts = JSONObject(response)
                .optJSONArray("candidates")
                ?.optJSONObject(0)
                ?.optJSONObject("content")
                ?.optJSONArray("parts")
            val sb = StringBuilder()
            if (parts != null) {
                for (i in 0 until parts.length()) {
                    sb.append(parts.optJSONObject(i)?.optString("text").orEmpty())
                }
            }
            val out = sb.toString().trim()
            if (out.isEmpty()) {
                Store.lastError = "Gemini رجّع رد فاضي (ممكن اتحجب لأسباب أمان)."
                null
            } else {
                if (Store.lastError.isNotEmpty()) Store.lastError = ""
                out
            }
        } catch (e: Exception) {
            Log.e(TAG, "request failed", e)
            Store.lastError = "تعذر الاتصال بـ Gemini: ${e.message}"
            null
        }
    }
}

package com.example.autoreply

import org.json.JSONObject
import java.util.UUID

object Apps {
    const val WHATSAPP = "com.whatsapp"
    const val BUSINESS = "com.whatsapp.w4b"
    const val MESSENGER = "com.facebook.orca"
    const val MESSENGER_LITE = "com.facebook.mlite"

    val supported = setOf(WHATSAPP, BUSINESS, MESSENGER, MESSENGER_LITE)

    fun label(pkg: String): String = when (pkg) {
        WHATSAPP -> "واتساب"
        BUSINESS -> "واتساب بيزنس"
        else -> "ماسنجر"
    }
}

enum class MatchType { ALL, KEYWORDS }

enum class ReplyMode { TEXT, AI, BOTH }

data class Rule(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "قاعدة جديدة",
    val enabled: Boolean = true,
    val whatsapp: Boolean = true,
    val business: Boolean = true,
    val messenger: Boolean = true,
    val match: MatchType = MatchType.ALL,
    val keywords: String = "",
    val mode: ReplyMode = ReplyMode.TEXT,
    val text: String = "",
    val aiPrompt: String = "",
    val scheduleOn: Boolean = false,
    val fromHour: Int = 18,
    val toHour: Int = 9,
    val cooldownMin: Int = 0,
) {
    fun appliesTo(pkg: String): Boolean = when (pkg) {
        Apps.WHATSAPP -> whatsapp
        Apps.BUSINESS -> business
        else -> messenger
    }

    fun matches(message: String): Boolean {
        if (match == MatchType.ALL) return true
        val words = keywords.split(',', '،', '\n')
            .map { it.trim().lowercase() }
            .filter { it.isNotEmpty() }
        if (words.isEmpty()) return false
        val m = message.lowercase()
        return words.any { m.contains(it) }
    }

    fun inSchedule(hour: Int): Boolean {
        if (!scheduleOn || fromHour == toHour) return true
        return if (fromHour < toHour) hour in fromHour until toHour
        else hour >= fromHour || hour < toHour
    }

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("name", name)
        put("enabled", enabled)
        put("whatsapp", whatsapp)
        put("business", business)
        put("messenger", messenger)
        put("match", match.name)
        put("keywords", keywords)
        put("mode", mode.name)
        put("text", text)
        put("aiPrompt", aiPrompt)
        put("scheduleOn", scheduleOn)
        put("fromHour", fromHour)
        put("toHour", toHour)
        put("cooldownMin", cooldownMin)
    }

    companion object {
        fun fromJson(o: JSONObject): Rule = Rule(
            id = o.optString("id", UUID.randomUUID().toString()),
            name = o.optString("name", "قاعدة"),
            enabled = o.optBoolean("enabled", true),
            whatsapp = o.optBoolean("whatsapp", true),
            business = o.optBoolean("business", true),
            messenger = o.optBoolean("messenger", true),
            match = runCatching { MatchType.valueOf(o.optString("match")) }.getOrDefault(MatchType.ALL),
            keywords = o.optString("keywords", ""),
            mode = runCatching { ReplyMode.valueOf(o.optString("mode")) }.getOrDefault(ReplyMode.TEXT),
            text = o.optString("text", ""),
            aiPrompt = o.optString("aiPrompt", ""),
            scheduleOn = o.optBoolean("scheduleOn", false),
            fromHour = o.optInt("fromHour", 18),
            toHour = o.optInt("toHour", 9),
            cooldownMin = o.optInt("cooldownMin", 0),
        )
    }
}

data class HistoryItem(
    val time: Long,
    val app: String,
    val contact: String,
    val incoming: String,
    val reply: String,
    val rule: String,
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("time", time)
        put("app", app)
        put("contact", contact)
        put("incoming", incoming)
        put("reply", reply)
        put("rule", rule)
    }

    companion object {
        fun fromJson(o: JSONObject) = HistoryItem(
            time = o.optLong("time"),
            app = o.optString("app"),
            contact = o.optString("contact"),
            incoming = o.optString("incoming"),
            reply = o.optString("reply"),
            rule = o.optString("rule"),
        )
    }
}

object Templates {
    fun absence() = Rule(
        name = "رد للغياب",
        text = "مرحبًا! أنا غير متاح حاليًا. سأرد بأسرع ما يمكن. شكرًا!",
        cooldownMin = 60,
    )

    fun outsideHours() = Rule(
        name = "خارج ساعات العمل",
        text = "مرحبًا! نحن غير متصلين حاليًا. سنرد خلال ساعات العمل. شكرًا على صبرك!",
        scheduleOn = true,
        fromHour = 18,
        toHour = 9,
        cooldownMin = 60,
    )

    fun busy() = Rule(
        name = "رد عند الانشغال",
        text = "نواجه حاليًا حجمًا كبيرًا من المحادثات وقد لا نتمكن من الرد فورًا. سنعود إليك بأسرع ما يمكن.",
        cooldownMin = 30,
    )

    fun vacation() = Rule(
        name = "رد للإجازة",
        text = "أنا حاليًا في إجازة وقد أكون بطيئًا في الرد. سأعود إليك فور رجوعي.",
        cooldownMin = 120,
    )

    fun smartAi() = Rule(
        name = "رد ذكي (Gemini)",
        mode = ReplyMode.AI,
    )
}

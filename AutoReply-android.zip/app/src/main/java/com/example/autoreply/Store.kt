package com.example.autoreply

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray

object Store {
    private lateinit var prefs: SharedPreferences

    /** يتغير كل ما حصل تعديل، عشان الواجهة تتحدث. */
    val version = MutableStateFlow(0)

    const val DEFAULT_PERSONA =
        "أنت مساعد بترد على رسائل واتساب وماسنجر نيابةً عن صاحب الحساب. " +
            "رد بنفس لغة ولهجة المرسل وباختصار وبأدب، ولا تخترع معلومات أو مواعيد أو أسعار. " +
            "لو السؤال محتاج صاحب الحساب نفسه قول إنه هيرد عليه في أقرب وقت."

    fun init(ctx: Context) {
        if (!::prefs.isInitialized) {
            prefs = ctx.applicationContext.getSharedPreferences("autoreply", Context.MODE_PRIVATE)
        }
    }

    fun bump() {
        version.value = version.value + 1
    }

    var enabled: Boolean
        get() = prefs.getBoolean("enabled", false)
        set(v) {
            prefs.edit().putBoolean("enabled", v).apply()
            bump()
        }

    var apiKey: String
        get() = prefs.getString("apiKey", "") ?: ""
        set(v) {
            prefs.edit().putString("apiKey", v.trim()).apply()
            bump()
        }

    var model: String
        get() = prefs.getString("model", "gemini-2.5-flash") ?: "gemini-2.5-flash"
        set(v) {
            prefs.edit().putString("model", v.trim()).apply()
            bump()
        }

    var persona: String
        get() = prefs.getString("persona", DEFAULT_PERSONA) ?: DEFAULT_PERSONA
        set(v) {
            prefs.edit().putString("persona", v).apply()
        }

    var ignoreGroups: Boolean
        get() = prefs.getBoolean("ignoreGroups", true)
        set(v) {
            prefs.edit().putBoolean("ignoreGroups", v).apply()
        }

    var lastError: String
        get() = prefs.getString("lastError", "") ?: ""
        set(v) {
            prefs.edit().putString("lastError", v).apply()
            bump()
        }

    fun rules(): List<Rule> {
        val raw = prefs.getString("rules", "[]") ?: "[]"
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { Rule.fromJson(arr.getJSONObject(it)) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun saveRules(list: List<Rule>) {
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        prefs.edit().putString("rules", arr.toString()).apply()
        bump()
    }

    /** الأحدث أولاً. */
    fun history(): List<HistoryItem> {
        val raw = prefs.getString("history", "[]") ?: "[]"
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { HistoryItem.fromJson(arr.getJSONObject(it)) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    @Synchronized
    fun addHistory(item: HistoryItem) {
        val list = (listOf(item) + history()).take(300)
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        prefs.edit().putString("history", arr.toString()).apply()
        bump()
    }

    fun clearHistory() {
        prefs.edit().putString("history", "[]").apply()
        bump()
    }
}

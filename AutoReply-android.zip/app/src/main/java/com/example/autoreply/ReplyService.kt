package com.example.autoreply

import android.app.Notification
import android.app.PendingIntent
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.RemoteInput
import java.util.Calendar
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

class ReplyService : NotificationListenerService() {

    private val executor = Executors.newSingleThreadExecutor()
    private val lastReplyAt = ConcurrentHashMap<String, Long>()
    private val lastSent = ConcurrentHashMap<String, String>()
    private val chats = ConcurrentHashMap<String, ArrayList<Pair<String, String>>>()
    private val handled = LinkedHashSet<String>()

    override fun onCreate() {
        super.onCreate()
        Store.init(this)
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        try {
            requestRebind(ComponentName(this, ReplyService::class.java))
        } catch (e: Exception) {
            Log.w(TAG, "rebind failed", e)
        }
    }

    override fun onDestroy() {
        executor.shutdown()
        super.onDestroy()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        Store.init(this)
        if (!Store.enabled) return

        val pkg = sbn.packageName ?: return
        if (pkg !in Apps.supported) return

        val n = sbn.notification ?: return
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return

        val extras = n.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim().orEmpty()
        if (title.isEmpty() || text.isEmpty()) return

        // تجاهل المجموعات
        val isGroup = extras.getBoolean("android.isGroupConversation", false) ||
            extras.getCharSequence("android.conversationTitle") != null
        if (Store.ignoreGroups && isGroup) return

        // تجاهل إشعارات "3 رسائل جديدة" وما شابه
        if (SUMMARY_REGEX.containsMatchIn(text)) return

        // تجاهل صدى ردودنا نحن
        val sent = lastSent[title]
        if (sent != null && (sent == text || (text.length >= 8 && sent.contains(text)))) return

        // تجاهل تكرار نفس الإشعار
        if (!firstTime("${sbn.key}|$text")) return

        val action = findReplyAction(n) ?: return

        executor.execute {
            try {
                process(pkg, title, text, action)
            } catch (e: Exception) {
                Log.e(TAG, "process failed", e)
            }
        }
    }

    private fun firstTime(key: String): Boolean = synchronized(handled) {
        if (!handled.add(key)) {
            false
        } else {
            if (handled.size > 300) handled.remove(handled.first())
            true
        }
    }

    private fun findReplyAction(n: Notification): NotificationCompat.Action? {
        val count = NotificationCompat.getActionCount(n)
        for (i in 0 until count) {
            val a = NotificationCompat.getAction(n, i) ?: continue
            if (!a.remoteInputs.isNullOrEmpty() && a.actionIntent != null) return a
        }
        for (a in NotificationCompat.WearableExtender(n).actions) {
            if (!a.remoteInputs.isNullOrEmpty() && a.actionIntent != null) return a
        }
        return null
    }

    private fun process(pkg: String, title: String, text: String, action: NotificationCompat.Action) {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val rule = Store.rules().firstOrNull {
            it.enabled && it.appliesTo(pkg) && it.matches(text) && it.inSchedule(hour)
        } ?: return

        val key = "${rule.id}|$pkg|$title"
        val now = System.currentTimeMillis()
        if (rule.cooldownMin > 0 && now - (lastReplyAt[key] ?: 0L) < rule.cooldownMin * 60_000L) return

        val fixed = rule.text.replace("{name}", title).trim()
        var aiText: String? = null

        if (rule.mode != ReplyMode.TEXT) {
            val ctxKey = "$pkg|$title"
            val hist = chats.getOrPut(ctxKey) { ArrayList() }
            val system = buildString {
                append(Store.persona)
                if (rule.aiPrompt.isNotBlank()) {
                    append("\n\nتعليمات إضافية: ")
                    append(rule.aiPrompt.trim())
                }
                append("\n\nاسم المرسل: ").append(title)
                append(". ردك هيتبعت كرسالة قصيرة في ").append(Apps.label(pkg)).append(".")
            }
            aiText = GeminiClient.reply(Store.apiKey, Store.model, system, hist.toList(), text)
            if (aiText != null) {
                hist.add("user" to text)
                hist.add("model" to aiText)
                while (hist.size > 12) {
                    hist.removeAt(0)
                    hist.removeAt(0)
                }
            }
        }

        val reply = when (rule.mode) {
            ReplyMode.TEXT -> fixed
            ReplyMode.AI -> aiText.orEmpty()
            ReplyMode.BOTH -> listOf(fixed, aiText.orEmpty()).filter { it.isNotBlank() }.joinToString("\n\n")
        }
        if (reply.isBlank()) return

        Thread.sleep(1000) // تأخير بسيط عشان الرد يبان طبيعي

        if (sendReply(action, reply)) {
            lastReplyAt[key] = System.currentTimeMillis()
            lastSent[title] = reply
            Store.addHistory(
                HistoryItem(System.currentTimeMillis(), Apps.label(pkg), title, text, reply, rule.name)
            )
        }
    }

    private fun sendReply(action: NotificationCompat.Action, message: String): Boolean {
        return try {
            val inputs = action.remoteInputs ?: return false
            val pi = action.actionIntent ?: return false
            val intent = Intent().addFlags(Intent.FLAG_RECEIVER_FOREGROUND)
            val bundle = Bundle()
            for (ri in inputs) bundle.putCharSequence(ri.resultKey, message)
            RemoteInput.addResultsToIntent(inputs, intent, bundle)
            pi.send(this, 0, intent)
            true
        } catch (e: PendingIntent.CanceledException) {
            Log.w(TAG, "reply action canceled", e)
            false
        }
    }

    companion object {
        private const val TAG = "ReplyService"
        private val SUMMARY_REGEX =
            Regex("^\\d+\\s+(new\\s+)?(messages?|رسائل|رسالة).*", RegexOption.IGNORE_CASE)
    }
}

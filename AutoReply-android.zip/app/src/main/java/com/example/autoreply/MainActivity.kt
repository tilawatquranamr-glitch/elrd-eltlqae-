package com.example.autoreply

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Green = Color(0xFF00B14F)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.init(this)
        setContent { AppRoot() }
    }

    override fun onResume() {
        super.onResume()
        Store.bump()
    }
}

@Composable
fun AppRoot() {
    val version by Store.version.collectAsState()
    var tab by remember { mutableIntStateOf(0) }
    var editing by remember { mutableStateOf<Rule?>(null) }

    BackHandler(enabled = editing != null) { editing = null }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Green,
            onPrimary = Color.White,
            primaryContainer = Color(0xFFC8F5DC),
            onPrimaryContainer = Color(0xFF00391A),
            secondaryContainer = Color(0xFFD6F5E3),
        )
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(Modifier.fillMaxSize(), color = Color(0xFFF7F8F7)) {
                val current = editing
                if (current != null) {
                    RuleEditor(
                        rule = current,
                        onCancel = { editing = null },
                        onSave = { saved ->
                            val list = Store.rules().toMutableList()
                            val i = list.indexOfFirst { it.id == saved.id }
                            if (i >= 0) list[i] = saved else list.add(saved)
                            Store.saveRules(list)
                            editing = null
                        },
                        onDelete = {
                            Store.saveRules(Store.rules().filter { it.id != current.id })
                            editing = null
                        },
                    )
                } else {
                    val tabs = listOf("🏠" to "الرئيسية", "📋" to "القواعد", "🕘" to "السجل", "⚙️" to "الإعدادات")
                    Scaffold(
                        containerColor = Color(0xFFF7F8F7),
                        bottomBar = {
                            NavigationBar(containerColor = Color.White) {
                                tabs.forEachIndexed { i, (icon, label) ->
                                    NavigationBarItem(
                                        selected = tab == i,
                                        onClick = { tab = i },
                                        icon = { Text(icon, fontSize = 20.sp) },
                                        label = { Text(label, fontSize = 12.sp) },
                                    )
                                }
                            }
                        },
                    ) { pad ->
                        Box(Modifier.padding(pad)) {
                            when (tab) {
                                0 -> HomeScreen(version)
                                1 -> RulesScreen(version) { editing = it }
                                2 -> HistoryScreen(version)
                                else -> SettingsScreen()
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Green)
            Text(label, fontSize = 12.sp, color = Color.Gray)
        }
    }
}

@Composable
fun HomeScreen(version: Int) {
    val ctx = LocalContext.current
    val hasAccess = remember(version) {
        NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
    }
    val enabled = remember(version) { Store.enabled }
    val rules = remember(version) { Store.rules() }
    val history = remember(version) { Store.history() }
    val lastError = remember(version) { Store.lastError }
    val usesAi = rules.any { it.enabled && it.mode != ReplyMode.TEXT }
    val keyMissing = remember(version) { Store.apiKey.isBlank() }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("الرد التلقائي القفاص", fontSize = 24.sp, fontWeight = FontWeight.Bold)

        if (!hasAccess) {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFE3E0))) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("الوصول إلى الإشعارات غير مفعّل", fontWeight = FontWeight.Bold)
                    Text(
                        "التطبيق بيقرأ إشعارات واتساب وماسنجر عشان يرد عليها. " +
                            "لو الخيار رمادي (أندرويد 13 أو أحدث): افتح معلومات التطبيق > ⋮ > السماح بالإعدادات المقيدة، وبعدها فعّله.",
                        fontSize = 13.sp,
                    )
                    Button(onClick = {
                        ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                    }) { Text("فتح إعدادات الإشعارات") }
                }
            }
        }

        Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
            Row(
                Modifier.fillMaxWidth().padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text(
                    if (enabled) "الرد التلقائي مفعّل" else "الرد التلقائي معطّل",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Medium,
                )
                Switch(checked = enabled, onCheckedChange = { Store.enabled = it })
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatCard("الردود", history.size.toString(), Modifier.weight(1f))
            StatCard("المحادثات", history.map { it.app + it.contact }.toSet().size.toString(), Modifier.weight(1f))
            StatCard("قواعد مفعّلة", rules.count { it.enabled }.toString(), Modifier.weight(1f))
        }

        if (usesAi && keyMissing) {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF3CD))) {
                Text(
                    "عندك قواعد بتستخدم الذكاء الاصطناعي لكن مفتاح Gemini مش متضاف. ضيفه من تبويب الإعدادات.",
                    Modifier.padding(16.dp),
                    fontSize = 13.sp,
                )
            }
        }

        if (lastError.isNotEmpty()) {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFE3E0))) {
                Column(Modifier.padding(16.dp)) {
                    Text("آخر خطأ", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text(lastError, fontSize = 13.sp)
                }
            }
        }

        OutlinedButton(
            onClick = { ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) },
            modifier = Modifier.fillMaxWidth(),
        ) { Text("استثناء التطبيق من توفير البطارية") }

        Text(
            "التطبيق بيرد بس والموبايل شغال ومتصل بالنت، وبيحتاج إن إشعارات واتساب وماسنجر تكون مفعّلة.",
            fontSize = 12.sp,
            color = Color.Gray,
        )
    }
}

@Composable
fun RulesScreen(version: Int, onEdit: (Rule) -> Unit) {
    val rules = remember(version) { Store.rules() }
    val templates: List<Pair<String, () -> Rule>> = listOf(
        "غياب" to { Templates.absence() },
        "خارج العمل" to { Templates.outsideHours() },
        "انشغال" to { Templates.busy() },
        "إجازة" to { Templates.vacation() },
        "رد ذكي" to { Templates.smartAi() },
        "قاعدة فارغة" to { Rule() },
    )

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item { Text("القواعد", fontSize = 24.sp, fontWeight = FontWeight.Bold) }
        item { Text("إضافة قاعدة من قالب", fontSize = 13.sp, color = Color.Gray) }
        templates.chunked(3).forEach { rowItems ->
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    rowItems.forEach { (label, make) ->
                        OutlinedButton(
                            onClick = { onEdit(make()) },
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(horizontal = 4.dp),
                        ) { Text(label, fontSize = 12.sp) }
                    }
                }
            }
        }
        if (rules.isEmpty()) {
            item {
                Text(
                    "لسه مفيش قواعد. التطبيق مش هيرد على أي رسالة غير لما تضيف قاعدة وتفعّلها.",
                    fontSize = 13.sp,
                    color = Color.Gray,
                )
            }
        }
        items(rules, key = { it.id }) { r ->
            Card(
                Modifier.fillMaxWidth().clickable { onEdit(r) },
                colors = CardDefaults.cardColors(containerColor = Color.White),
            ) {
                Row(
                    Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(r.name, fontWeight = FontWeight.Bold)
                        val mode = when (r.mode) {
                            ReplyMode.TEXT -> "نص مكتوب"
                            ReplyMode.AI -> "ذكاء اصطناعي"
                            ReplyMode.BOTH -> "نص + ذكاء اصطناعي"
                        }
                        val apps = listOfNotNull(
                            if (r.whatsapp) "واتساب" else null,
                            if (r.business) "بيزنس" else null,
                            if (r.messenger) "ماسنجر" else null,
                        ).joinToString("، ")
                        Text("$mode • $apps", fontSize = 12.sp, color = Color.Gray)
                    }
                    Switch(
                        checked = r.enabled,
                        onCheckedChange = { v ->
                            Store.saveRules(Store.rules().map { if (it.id == r.id) it.copy(enabled = v) else it })
                        },
                    )
                }
            }
        }
        item {
            Text(
                "لو أكتر من قاعدة اتطابقت مع الرسالة، أول قاعدة مفعّلة في القائمة هي اللي بترد.",
                fontSize = 12.sp,
                color = Color.Gray,
            )
        }
    }
}

@Composable
fun <T> Choice(options: List<Pair<T, String>>, selected: T, onSelect: (T) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { (value, label) ->
            if (value == selected) {
                Button(
                    onClick = { onSelect(value) },
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(horizontal = 4.dp),
                ) { Text(label, fontSize = 12.sp) }
            } else {
                OutlinedButton(
                    onClick = { onSelect(value) },
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(horizontal = 4.dp),
                ) { Text(label, fontSize = 12.sp) }
            }
        }
    }
}

@Composable
fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(label)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun RuleEditor(rule: Rule, onSave: (Rule) -> Unit, onCancel: () -> Unit, onDelete: () -> Unit) {
    var r by remember(rule.id) { mutableStateOf(rule) }
    var fromS by remember(rule.id) { mutableStateOf(rule.fromHour.toString()) }
    var toS by remember(rule.id) { mutableStateOf(rule.toHour.toString()) }
    var coolS by remember(rule.id) { mutableStateOf(rule.cooldownMin.toString()) }
    var errorMsg by remember(rule.id) { mutableStateOf("") }
    val exists = remember(rule.id) { Store.rules().any { it.id == rule.id } }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text(if (exists) "تعديل القاعدة" else "قاعدة جديدة", fontSize = 22.sp, fontWeight = FontWeight.Bold)

        OutlinedTextField(
            value = r.name,
            onValueChange = { r = r.copy(name = it) },
            label = { Text("اسم القاعدة") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
        )

        Text("التطبيقات", fontWeight = FontWeight.Medium)
        SwitchRow("واتساب", r.whatsapp) { r = r.copy(whatsapp = it) }
        SwitchRow("واتساب بيزنس", r.business) { r = r.copy(business = it) }
        SwitchRow("ماسنجر", r.messenger) { r = r.copy(messenger = it) }

        Text("الرد على", fontWeight = FontWeight.Medium)
        Choice(
            listOf(MatchType.ALL to "كل الرسائل", MatchType.KEYWORDS to "كلمات معينة"),
            r.match,
        ) { r = r.copy(match = it) }
        if (r.match == MatchType.KEYWORDS) {
            OutlinedTextField(
                value = r.keywords,
                onValueChange = { r = r.copy(keywords = it) },
                label = { Text("الكلمات (افصل بينها بفاصلة)") },
                modifier = Modifier.fillMaxWidth(),
            )
        }

        Text("نوع الرد", fontWeight = FontWeight.Medium)
        Choice(
            listOf(
                ReplyMode.TEXT to "نص مكتوب",
                ReplyMode.AI to "ذكاء اصطناعي",
                ReplyMode.BOTH to "الاتنين",
            ),
            r.mode,
        ) { r = r.copy(mode = it) }

        if (r.mode != ReplyMode.AI) {
            OutlinedTextField(
                value = r.text,
                onValueChange = { r = r.copy(text = it) },
                label = { Text("نص الرد") },
                supportingText = { Text("اكتب {name} لو عايز اسم المرسل يظهر في الرد") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 3,
            )
        }
        if (r.mode != ReplyMode.TEXT) {
            OutlinedTextField(
                value = r.aiPrompt,
                onValueChange = { r = r.copy(aiPrompt = it) },
                label = { Text("تعليمات للذكاء الاصطناعي (اختياري)") },
                supportingText = { Text("مثلاً: نحن محل ملابس، الدوام من 10 لـ 8، التوصيل 50 جنيه") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 3,
            )
            if (r.mode == ReplyMode.BOTH) {
                Text(
                    "في وضع \"الاتنين\" بيتبعت النص المكتوب وتحته رد الذكاء الاصطناعي في نفس الرسالة.",
                    fontSize = 12.sp,
                    color = Color.Gray,
                )
            }
        }

        SwitchRow("تحديد ساعات للرد", r.scheduleOn) { r = r.copy(scheduleOn = it) }
        if (r.scheduleOn) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = fromS,
                    onValueChange = { fromS = it.filter(Char::isDigit).take(2) },
                    label = { Text("من الساعة (0-23)") },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                )
                OutlinedTextField(
                    value = toS,
                    onValueChange = { toS = it.filter(Char::isDigit).take(2) },
                    label = { Text("إلى الساعة (0-23)") },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                )
            }
        }

        OutlinedTextField(
            value = coolS,
            onValueChange = { coolS = it.filter(Char::isDigit).take(4) },
            label = { Text("لا ترد على نفس الشخص أكتر من مرة كل (دقيقة)") },
            supportingText = { Text("0 = رد على كل رسالة") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        )

        if (errorMsg.isNotEmpty()) Text(errorMsg, color = Color(0xFFB3261E), fontSize = 13.sp)

        Button(
            onClick = {
                val saved = r.copy(
                    name = r.name.trim().ifEmpty { "قاعدة" },
                    fromHour = fromS.toIntOrNull()?.coerceIn(0, 23) ?: r.fromHour,
                    toHour = toS.toIntOrNull()?.coerceIn(0, 23) ?: r.toHour,
                    cooldownMin = coolS.toIntOrNull() ?: 0,
                )
                errorMsg = when {
                    saved.mode == ReplyMode.TEXT && saved.text.isBlank() ->
                        "اكتب نص الرد"
                    saved.mode == ReplyMode.BOTH && saved.text.isBlank() && saved.aiPrompt.isBlank() ->
                        "اكتب نص الرد أو تعليمات للذكاء الاصطناعي"
                    saved.match == MatchType.KEYWORDS && saved.keywords.isBlank() ->
                        "اكتب كلمة واحدة على الأقل"
                    !saved.whatsapp && !saved.business && !saved.messenger ->
                        "اختار تطبيق واحد على الأقل"
                    else -> ""
                }
                if (errorMsg.isEmpty()) onSave(saved)
            },
            modifier = Modifier.fillMaxWidth(),
        ) { Text("حفظ") }

        OutlinedButton(onClick = onCancel, modifier = Modifier.fillMaxWidth()) { Text("إلغاء") }
        if (exists) {
            TextButton(onClick = onDelete, modifier = Modifier.fillMaxWidth()) {
                Text("حذف القاعدة", color = Color(0xFFB3261E))
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
fun HistoryScreen(version: Int) {
    val list = remember(version) { Store.history() }
    val fmt = remember { SimpleDateFormat("d/M  HH:mm", Locale.getDefault()) }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text("السجل", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                if (list.isNotEmpty()) TextButton(onClick = { Store.clearHistory() }) { Text("مسح الكل") }
            }
        }
        if (list.isEmpty()) {
            item { Text("مفيش ردود لسه.", color = Color.Gray) }
        }
        items(list) { h ->
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("${h.app} • ${h.contact}", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("وارد: ${h.incoming}", fontSize = 13.sp)
                    Text("الرد: ${h.reply}", fontSize = 13.sp, color = Green)
                    Text("${fmt.format(Date(h.time))} • ${h.rule}", fontSize = 11.sp, color = Color.Gray)
                }
            }
        }
    }
}

@Composable
fun SettingsScreen() {
    var key by remember { mutableStateOf(Store.apiKey) }
    var model by remember { mutableStateOf(Store.model) }
    var persona by remember { mutableStateOf(Store.persona) }
    var groups by remember { mutableStateOf(Store.ignoreGroups) }
    var testResult by remember { mutableStateOf("") }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("الإعدادات", fontSize = 24.sp, fontWeight = FontWeight.Bold)

        OutlinedTextField(
            value = key,
            onValueChange = { key = it; Store.apiKey = it },
            label = { Text("مفتاح Gemini API") },
            supportingText = { Text("من aistudio.google.com. بيتخزن على جهازك بس.") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
        )

        Text("الموديل", fontWeight = FontWeight.Medium)
        Choice(
            listOf(
                "gemini-2.5-flash" to "Flash",
                "gemini-2.5-flash-lite" to "Flash-Lite",
                "gemini-2.5-pro" to "Pro",
            ),
            model,
        ) { model = it; Store.model = it }
        OutlinedTextField(
            value = model,
            onValueChange = { model = it; Store.model = it },
            label = { Text("اسم الموديل") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
        )

        OutlinedTextField(
            value = persona,
            onValueChange = { persona = it; Store.persona = it },
            label = { Text("شخصية الذكاء الاصطناعي (تعليمات عامة)") },
            modifier = Modifier.fillMaxWidth(),
            minLines = 4,
        )

        SwitchRow("تجاهل رسائل المجموعات", groups) { groups = it; Store.ignoreGroups = it }

        Button(
            onClick = {
                testResult = "جاري الاختبار..."
                Thread {
                    val r = GeminiClient.reply(Store.apiKey, Store.model, "رد بجملة قصيرة جداً.", emptyList(), "قول مرحبا")
                    Handler(Looper.getMainLooper()).post {
                        testResult = if (r != null) "شغال ✔ الرد: $r" else "فشل: ${Store.lastError}"
                    }
                }.start()
            },
            modifier = Modifier.fillMaxWidth(),
        ) { Text("اختبار الاتصال بـ Gemini") }
        if (testResult.isNotEmpty()) Text(testResult, fontSize = 13.sp)

        Text(
            "تنبيه خصوصية: لما قاعدة تستخدم الذكاء الاصطناعي، نص رسالة العميل بيتبعت لـ Google عشان يتولد الرد.",
            fontSize = 12.sp,
            color = Color.Gray,
        )
    }
}
